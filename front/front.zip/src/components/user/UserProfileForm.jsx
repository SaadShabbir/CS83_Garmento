import React, { Component } from 'react';
import BoughtProducts from '../adminPanel/users/BoughtProducts';

const UserProfile = ()=>{
    return(
        <BoughtProducts data={}/>
    )
}