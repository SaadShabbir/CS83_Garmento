import React from 'react';
import Footer from '../common/Footer';

// import { Route, Link } from 'react-router-dom';

import Body from './MainBody';

const MainHome = props => {
  return (
    <Body />
  );
};

export default MainHome;
