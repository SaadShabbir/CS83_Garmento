import React from 'react';
import ProductList2 from "./ProductList2";

const ShopWhole = (props) => {
  return (
    <>
      <ProductList2 {...props} />
    </>
  );
};

export default ShopWhole;
